Put functions that are specific to a given client here and require them in your configuration
These functions must be present in the docker image
