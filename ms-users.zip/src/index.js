/**
 * Exports users service
 * @return {Users}
 */
module.exports = require('./users.js');
